# Phase 3: Multiplayer!
Refactor your game to work with more than just two players. Instead of ending the game when one of the players reaches five losses, simply exclude that player from further rounds. End the game when only one player is left standing. 

- Hint: You won't be able to use an instance variable for each player anymore. What data structure might we use as an alternative?